const http = require("http");
const fs = require("fs");
const path = require("path");

const { derivative, secondDerivative, newton, bisection, simpson, trapezoidal, rk4 } = require("./engine/numerical");
const { factorial, taylor, geometricSeries, infiniteGeometric } = require("./engine/series");
const { fourierCoefficients } = require("./engine/fourier");
const { gradient, laplacian } = require("./engine/multivariable");
const { solveFirstOrder } = require("./engine/ode");

const PORT = process.env.PORT || 3000;

const FUNCTIONS = {
    sqrt: Math.sqrt, abs: Math.abs, sin: Math.sin, cos: Math.cos,
    tan: Math.tan, log: Math.log, ln: Math.log, exp: Math.exp,
    asin: Math.asin, acos: Math.acos, atan: Math.atan
};

function fmt(v) {
    if (typeof v !== "number" || !Number.isFinite(v)) return String(v);
    if (Math.abs(v) < 1e-12) v = 0;
    return Number(v.toFixed(10)).toString();
}

function normalize(s) {
    return String(s)
        .toLowerCase()
        .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
        .replace(/[×·]/g, "*").replace(/÷/g, "/")
        .replace(/[−–—]/g, "-")
        .replace(/π/g, "pi")
        .replace(/√/g, "sqrt")
        .replace(/²/g, "^2").replace(/³/g, "^3").replace(/⁴/g, "^4")
        .replace(/\s+/g, " ").trim();
}

function expressionForJS(expr, vars = {}) {
    let s = normalize(expr)
        .replace(/\bpi\b/g, "Math.PI")
        .replace(/\be\b/g, "Math.E")
        .replace(/\bln\(/g, "Math.log(");

    for (const fn of Object.keys(FUNCTIONS)) {
        if (fn !== "ln") s = s.replace(new RegExp("\\b" + fn + "\\(", "g"), "Math." + fn + "(");
    }

    s = s.replace(/\^/g, "**");
    s = s.replace(/(\d|\))(?=\()/g, "$1*");
    s = s.replace(/(\d|\))(?=(Math\.|x\b|y\b))/g, "$1*");
    s = s.replace(/(\bx\b|\by\b)(?=\()/g, "$1*");

    for (const [name, value] of Object.entries(vars)) {
        s = s.replace(new RegExp("\\b" + name + "\\b", "g"), "(" + Number(value) + ")");
    }

    if (!/^[0-9+\-*/().,\sA-Za-z_]+$/.test(s)) throw new Error("Expressão contém símbolos não suportados.");
    if (/(constructor|prototype|__proto__|require|process|global|Function|eval)/i.test(s)) throw new Error("Expressão não permitida.");

    return s;
}

function evalNumber(expr) {
    const s = expressionForJS(expr);
    if (/\bx\b|\by\b/.test(s)) throw new Error("A expressão contém variáveis.");
    const value = Function('"use strict"; return (' + s + ')')();
    if (typeof value !== "number" || !Number.isFinite(value)) throw new Error("Expressão inválida.");
    return value;
}

function evalX(expr, x) {
    const s = expressionForJS(expr, { x });
    const value = Function('"use strict"; return (' + s + ')')();
    if (typeof value !== "number" || !Number.isFinite(value)) throw new Error("Função inválida.");
    return value;
}

function evalXY(expr, x, y) {
    const s = expressionForJS(expr, { x, y });
    const value = Function('"use strict"; return (' + s + ')')();
    if (typeof value !== "number" || !Number.isFinite(value)) throw new Error("Função inválida.");
    return value;
}

function parseNum(s) {
    const n = Number(String(s).replace(",", "."));
    if (!Number.isFinite(n)) throw new Error("Número inválido.");
    return n;
}

function polynomialCoefficients(text) {
    let eq = normalize(text);
    if (!eq.includes("=")) throw new Error("Equação sem '='.");
    const [left, right] = eq.split("=").map(s => s.trim());

    function parseSide(side) {
        side = side.replace(/\s/g, "").replace(/\(/g, "").replace(/\)/g, "");
        side = side.replace(/-/g, "+-");
        if (side.startsWith("+")) side = side.slice(1);
        const terms = side.split("+").filter(Boolean);
        const c = [0,0,0,0,0];

        for (let term of terms) {
            let sign = 1;
            if (term.startsWith("-")) { sign = -1; term = term.slice(1); }
            if (!term) continue;

            const xm = term.match(/^([0-9.]*)(?:\*?)x(?:\^(\d+))?$/);
            if (xm) {
                let coef = xm[1] === "" ? 1 : Number(xm[1]);
                const deg = xm[2] ? Number(xm[2]) : 1;
                if (!Number.isFinite(coef) || deg > 4) throw new Error("Grau superior a 4 não suportado.");
                c[deg] += sign * coef;
            } else {
                const n = Number(term);
                if (!Number.isFinite(n)) throw new Error("Equação polinomial inválida.");
                c[0] += sign * n;
            }
        }
        return c;
    }

    const L = parseSide(left), R = parseSide(right);
    const c = L.map((v,i) => v - R[i]);
    while (c.length > 1 && Math.abs(c[c.length-1]) < 1e-12) c.pop();
    return c;
}

function solveLinear(text) {
    const [left,right] = normalize(text).split("=");
    const f = x => evalX(left,x) - evalX(right,x);
    const a = f(1)-f(0), b=f(0);
    if (Math.abs(a)<1e-12) return Math.abs(b)<1e-12
        ? { result:"Infinitas soluções", steps:["Os dois lados são equivalentes."] }
        : { result:"Sem solução", steps:["A igualdade não pode ser satisfeita."] };
    const x=-b/a;
    return { result:`x = ${fmt(x)}`, steps:[`Equação: ${text}`,`Forma reduzida: ${fmt(a)}x ${b>=0?"+":"-"} ${fmt(Math.abs(b))} = 0`,`x = -b/a = ${fmt(x)}`] };
}

function solveQuadratic(c) {
    const [cc,b,a]=c, D=b*b-4*a*cc;
    const steps=[`Forma padrão: ${fmt(a)}x² ${b>=0?"+":"-"} ${fmt(Math.abs(b))}x ${cc>=0?"+":"-"} ${fmt(Math.abs(cc))} = 0`,`Δ = ${fmt(D)}`];
    if(D<0){const re=-b/(2*a), im=Math.sqrt(-D)/(2*a);return{result:`x₁ = ${fmt(re)} + ${fmt(im)}i; x₂ = ${fmt(re)} - ${fmt(im)}i`,steps:steps.concat(["Δ < 0, portanto as raízes são complexas."])};}
    const d=Math.sqrt(D), x1=(-b+d)/(2*a), x2=(-b-d)/(2*a);
    return {result:`x₁ = ${fmt(x1)}, x₂ = ${fmt(x2)}`,steps:steps.concat([`x₁ = ${fmt(x1)}`,`x₂ = ${fmt(x2)}`])};
}

function solvePolynomialNumerical(c) {
    const degree=c.length-1;
    const f=x=>c.reduce((s,a,i)=>s+a*x**i,0);
    const df=x=>c.slice(1).reduce((s,a,i)=>s+(i+1)*a*x**i,0);
    const roots=[];
    for(let a=-100;a<100 && roots.length<degree;a+=0.25){
        const b=a+0.25, fa=f(a), fb=f(b);
        if(Math.abs(fa)<1e-8 && !roots.some(r=>Math.abs(r-a)<1e-6)) roots.push(a);
        if(fa*fb<0){try{const r=bisection(f,a,b);if(!roots.some(q=>Math.abs(q-r)<1e-6))roots.push(r);}catch{}}
    }
    for(let x0=-20;x0<=20 && roots.length<degree;x0++){
        try{const r=newton(f,df,x0);if(Number.isFinite(r)&&Math.abs(f(r))<1e-6&&!roots.some(q=>Math.abs(q-r)<1e-5))roots.push(r);}catch{}
    }
    roots.sort((a,b)=>a-b);
    if(!roots.length) throw new Error("Não encontrei raízes reais com os métodos atuais.");
    return {result:roots.map((r,i)=>`x${i+1} = ${fmt(r)}`).join(", "),steps:[`Equação de grau ${degree}.`,`Procura numérica de raízes reais usando bisseção e Newton.`,`Raízes encontradas: ${roots.map(fmt).join(", ")}`]};
}

function naturalDerivative(text) {
    const m=normalize(text).match(/(?:qual e a |calcule |encontre |obtenha )?(?:a )?(?:derivada|derivative)(?: de| da| do)? (.+?)(?: em x\s*=\s*| em\s+| no ponto x\s*=\s*)(-?\d+(?:[.,]\d+)?)$/);
    if(!m) return null;
    const expr=m[1].trim(), x=parseNum(m[2]);
    const f=t=>evalX(expr,t), d=derivative(f,x);
    return {tipo:"Derivada",passos:[`Função: f(x) = ${expr}`,`Ponto: x = ${fmt(x)}`,`Usando derivada numérica central: f'(x) ≈ ${fmt(d)}`],resultado:fmt(d)};
}

function naturalIntegral(text) {
    const m=normalize(text).match(/(?:calcule |encontre )?(?:a )?(?:integral|integração)(?: definida)? de (.+?) (?:de|entre|from)\s*(-?\d+(?:[.,]\d+)?) (?:a|ate|to)\s*(-?\d+(?:[.,]\d+)?)/);
    if(!m) return null;
    const expr=m[1].trim(), a=parseNum(m[2]), b=parseNum(m[3]), f=x=>evalX(expr,x);
    const v=simpson(f,a,b);
    return {tipo:"Integral definida",passos:[`Função: ${expr}`,`Limites: ${fmt(a)} e ${fmt(b)}`,`Método de Simpson numérico`,`∫ f(x) dx ≈ ${fmt(v)}`],resultado:fmt(v)};
}

function naturalBasic(text) {
    let s=normalize(text)
        .replace(/^(quanto e|quanto é|calcule|resolva|qual e|qual é|resultado de)\s+/,"")
        .replace(/\bvezes\b/g,"*").replace(/\bdividido por\b/g,"/")
        .replace(/\bmais\b/g,"+").replace(/\bmenos\b/g,"-")
        .replace(/\bao quadrado\b/g,"^2").replace(/\ba terceira potencia\b/g,"^3");
    return s;
}

function solve(question) {
    const original=String(question||"").trim();
    if(!original) throw new Error("Digite um problema.");
    const text=normalize(original);

    const d=naturalDerivative(text); if(d)return d;
    const i=naturalIntegral(text); if(i)return i;

    const fact=text.match(/(?:calcule\s+)?(?:o\s+)?fatorial\s+(?:de\s+)?(\d+)/);
    if(fact){const n=Number(fact[1]),v=factorial(n);return{tipo:"Fatorial",passos:[`${n}! = 1 × 2 × ... × ${n}`,`Resultado do fatorial.`],resultado:String(v)};}

    const sqrt=text.match(/(?:raiz quadrada de|sqrt)\s*(?:\(?\s*)(-?\d+(?:[.,]\d+)?)\s*\)?/);
    if(sqrt){const n=parseNum(sqrt[1]);if(n<0)throw new Error("Raiz quadrada real de número negativo não existe.");return{tipo:"Raiz quadrada",passos:[`√${fmt(n)}`,`√${fmt(n)} = ${fmt(Math.sqrt(n))}`],resultado:fmt(Math.sqrt(n))};}

    if(text.includes("=")&&/[a-z]/i.test(text)){
        try{
            const c=polynomialCoefficients(text), degree=c.length-1;
            if(degree===1){const r=solveLinear(text);return{tipo:"Equação do 1.º grau",passos:r.steps,resultado:r.result};}
            if(degree===2){const r=solveQuadratic(c);return{tipo:"Equação do 2.º grau",passos:r.steps,resultado:r.result};}
            if(degree>=3&&degree<=4){const r=solvePolynomialNumerical(c);return{tipo:`Equação de ${degree}.º grau`,passos:r.steps,resultado:r.result};}
        }catch(e){}
    }

    const grad=text.match(/gradiente(?: de)?\s+(.+?)\s+(?:em|no ponto)\s*x\s*=\s*(-?\d+(?:[.,]\d+)?)\s*(?:,|e|;)\s*y\s*=\s*(-?\d+(?:[.,]\d+)?)/);
    if(grad){const expr=grad[1],x=parseNum(grad[2]),y=parseNum(grad[3]),g=gradient((a,b)=>evalXY(expr,a,b),x,y);return{tipo:"Gradiente",passos:[`f(x,y) = ${expr}`,`Ponto: (${fmt(x)}, ${fmt(y)})`,`∂f/∂x ≈ ${fmt(g.dx)}`,`∂f/∂y ≈ ${fmt(g.dy)}`],resultado:`∇f ≈ (${fmt(g.dx)}, ${fmt(g.dy)})`};}

    const geo=text.match(/soma geometrica.*?a\s*=\s*(-?\d+(?:[.,]\d+)?).*?r\s*=\s*(-?\d+(?:[.,]\d+)?).*?n\s*=\s*(\d+)/);
    if(geo){const a=parseNum(geo[1]),r=parseNum(geo[2]),n=Number(geo[3]),v=geometricSeries(a,r,n);return{tipo:"Série geométrica",passos:[`a = ${fmt(a)}`,`r = ${fmt(r)}`,`n = ${n}`,`Aplicando Sₙ = a(1-rⁿ)/(1-r)`],resultado:fmt(v)};}

    const ode=text.match(/(?:resolver\s+)?ode\s+y['′]\s*=\s*(.+?)\s+x0\s*=\s*(-?\d+(?:[.,]\d+)?)\s+y0\s*=\s*(-?\d+(?:[.,]\d+)?)\s+h\s*=\s*(-?\d+(?:[.,]\d+)?)\s+steps\s*=\s*(\d+)/);
    if(ode){const expr=ode[1],x0=parseNum(ode[2]),y0=parseNum(ode[3]),h=parseNum(ode[4]),steps=Number(ode[5]);const rows=solveFirstOrder((x,y)=>evalX(expr.replace(/\by\b/g,`(${y})`),x),x0,y0,h,steps),last=rows[rows.length-1];return{tipo:"EDO de 1.ª ordem — RK4",passos:[`y' = ${expr}`,`x₀ = ${fmt(x0)}, y₀ = ${fmt(y0)}`,`h = ${fmt(h)}, passos = ${steps}`,`x final = ${fmt(last.x)}`],resultado:`y ≈ ${fmt(last.y)}`};}

    const basic=naturalBasic(original);
    try{const v=evalNumber(basic);return{tipo:"Cálculo básico",passos:[`Expressão interpretada: ${basic}`,`Calculando...`,`Resultado = ${fmt(v)}`],resultado:fmt(v)};}catch{}

    throw new Error("Ainda não reconheço esse formato. Tente escrever a pergunta de forma simples, por exemplo: “qual é a derivada de x^2 em x=3?”");
}

function send(res,status,data){res.writeHead(status,{"Content-Type":"application/json; charset=utf-8"});res.end(JSON.stringify(data));}

function staticFile(req,res){
    const files={"/": ["index.html","text/html; charset=utf-8"],"/index.html":["index.html","text/html; charset=utf-8"],"/script.js":["script.js","application/javascript; charset=utf-8"],"/style.css":["style.css","text/css; charset=utf-8"]};
    const item=files[req.url.split("?")[0]];
    if(!item){res.writeHead(404);return res.end("Não encontrado.");}
    fs.readFile(path.join(__dirname,"public",item[0]),(e,d)=>{if(e){res.writeHead(404);return res.end("Arquivo não encontrado.");}res.writeHead(200,{"Content-Type":item[1]});res.end(d);});
}

const server=http.createServer((req,res)=>{
    if(req.method==="POST"&&req.url==="/api/solve"){
        let body="";
        req.on("data",c=>body+=c);
        req.on("end",()=>{try{const q=JSON.parse(body).question;send(res,200,solve(q));}catch(e){send(res,400,{tipo:"Erro",passos:[e.message],resultado:"Não foi possível resolver."});}});
        return;
    }
    if(req.method==="GET"&&(req.url==="/"||req.url.startsWith("/index.html")||req.url==="/script.js"||req.url==="/style.css")) return staticFile(req,res);
    if(req.method==="GET"&&req.url==="/health") return send(res,200,{status:"ok",dream:"online"});
    res.writeHead(404);res.end("Rota não encontrada.");
});

server.listen(PORT,"0.0.0.0",()=>console.log(`DREAM AI ONLINE — PORTA ${PORT}`));
